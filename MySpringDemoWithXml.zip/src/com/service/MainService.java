package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MainDaoImpl;
import com.entity.UserBo;


@Service
public class MainService {

	@Autowired
	private MainDaoImpl daoImpl;
	
	public String getMyMethod(){
		
	//	System.out.println("MainService...");
		return daoImpl.getDaoName();
		
	}

	public String saveData(UserBo userBo) {
		System.out.println("MainService...saveData");
		return daoImpl.saveData(userBo);
	}
	
}
