package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.entity.UserBo;

@Repository
public class MainDaoImpl {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}


	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	public String getDaoName(){
		//System.out.println("MainService...");
		return "MainDaoImpl...??";
	}


	public String saveData(UserBo userBo) {
		String msg=null;
		Session session=null;
		Transaction tx=null;
		try{
			System.out.println("MainDaoImpl...saveData");
		 session=sessionFactory.openSession();
		tx=session.beginTransaction();
		
		System.out.println(userBo.getF_name());
		System.out.println(userBo.getL_name());
		userBo.setId(1);
		if(userBo!=null){
		session.save(userBo);
		tx.commit();
		
		}
		if(session!=null){
			msg="user data Saved Sucessfully....";
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			session.clear();
			session.close();
		}
		
		return msg;
	}

}
