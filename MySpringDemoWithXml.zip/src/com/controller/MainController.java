package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.entity.UserBo;
import com.service.MainService;



@Controller("/mainController")
@EnableWebMvc
public class MainController {
	
	@Autowired
	private MainService service ;
	
	@RequestMapping(value="/showPage",method=RequestMethod.POST)
	public ModelAndView showPage(@ModelAttribute("userBo")UserBo userBo,HttpServletRequest request,HttpServletResponse response){
		ModelAndView m=new ModelAndView("welCome");
		
		//System.out.println("monika makwana");
	    String name=service.getMyMethod();
	   // m.addObject("UserBo", new UserBo());
	    m.addObject("name",name);
		return  m;
	}
	
	
	
	@RequestMapping(value="/SaveName",method=RequestMethod.POST)
	public ModelAndView SaveName(@ModelAttribute("userBo")UserBo userBo,HttpServletRequest request,HttpServletResponse response){
		ModelAndView m=new ModelAndView("welCome");
		
		System.out.println("MainController...saveData");
	 //   String name=service.getMyMethod();
		/*String fn=request.getParameter("f_name");
		String ln=request.getParameter("l_name");
		userBo.setF_name(fn);
		userBo.setL_name(ln);*/
	    String msg=service.saveData(userBo);
	    
        m.addObject("msg", msg);
        System.out.println("msg...."+msg);
//	    m.addObject("name",name);
	   /* m.addObject("id", "1234");*/
		return  m;
	}
	
	

}
